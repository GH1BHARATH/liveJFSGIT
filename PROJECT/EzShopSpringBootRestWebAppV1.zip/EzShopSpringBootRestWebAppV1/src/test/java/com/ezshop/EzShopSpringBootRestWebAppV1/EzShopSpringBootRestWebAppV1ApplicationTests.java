package com.ezshop.EzShopSpringBootRestWebAppV1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EzShopSpringBootRestWebAppV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
